const KEY="mm_hostel_manager_v1";
const defaultState={
 settings:{hostelName:"M&M Hostel",managerName:"Manager",defaultRent:5000},
 holiday:{enabled:false,start:"",generalReport:"",rent:2000,notes:""},
 rooms:Array.from({length:65},(_,i)=>({id:String(i+1),status:"available",tenantId:null,rent:5000})),
 tenants:[],
 payments:[],
 shops:[{id:1,name:"Shop 1",tenant:"Available",rent:10000},{id:2,name:"Shop 2",tenant:"Available",rent:10000},{id:3,name:"Shop 3",tenant:"Available",rent:10000}]
};
let state=load();

function load(){try{return JSON.parse(localStorage.getItem(KEY))||structuredClone(defaultState)}catch{return structuredClone(defaultState)}}
function save(){localStorage.setItem(KEY,JSON.stringify(state)); renderAll()}
function money(n){return "KSh "+Number(n||0).toLocaleString()}
function todayISO(){return new Date().toISOString().slice(0,10)}
function fmtDate(d){if(!d)return "—";return new Date(d+"T00:00:00").toLocaleDateString("en-KE",{day:"2-digit",month:"short",year:"numeric"})}
function toast(msg){const t=document.getElementById("toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2200)}
function tenantById(id){return state.tenants.find(t=>t.id===id)}
function roomById(id){return state.rooms.find(r=>r.id===String(id))}
function balance(t){return Math.max(0,(t.balance||0))}
function rentFor(t){return state.holiday.enabled ? Number(state.holiday.rent||t.rent) : Number(t.rent)}
function lastPayment(t){return state.payments.filter(p=>p.tenantId===t.id).sort((a,b)=>b.date.localeCompare(a.date))[0]}

const pageInfo={
 dashboard:["Dashboard","Overview of your hostel operations"],rooms:["Rooms","65 rooms and current occupancy"],tenants:["Tenants","Registered students and room assignments"],
 payments:["Payments","Rent collection and transactions"],receipts:["Receipts","Payment receipts"],defaulters:["Defaulters","Outstanding rent balances"],
 shops:["Shops","Three commercial spaces"],reports:["Reports","Operational and financial summaries"],holiday:["Holiday Mode","Long holiday and student reporting"],settings:["Settings","Hostel configuration"]
};
function go(page){
 document.querySelectorAll(".page").forEach(p=>p.classList.toggle("active",p.id===page));
 document.querySelectorAll(".nav-btn").forEach(b=>b.classList.toggle("active",b.dataset.page===page));
 document.getElementById("pageTitle").textContent=pageInfo[page][0];document.getElementById("pageSubtitle").textContent=pageInfo[page][1];
 window.scrollTo({top:0,behavior:"smooth"});
}
document.querySelectorAll(".nav-btn").forEach(b=>b.onclick=()=>go(b.dataset.page));
document.querySelectorAll("[data-page-jump]").forEach(b=>b.onclick=()=>go(b.dataset.pageJump));
document.getElementById("mobileMenu").onclick=()=>document.querySelector(".sidebar").classList.toggle("open");
document.getElementById("today").textContent=new Date().toLocaleDateString("en-KE",{weekday:"short",day:"numeric",month:"short",year:"numeric"});

function renderDashboard(){
 const occupied=state.rooms.filter(r=>r.status==="occupied").length;
 const reserved=state.rooms.filter(r=>r.status==="reserved").length;
 const available=65-occupied-reserved;
 const total=state.payments.reduce((s,p)=>s+Number(p.amount),0);
 const out=state.tenants.reduce((s,t)=>s+balance(t),0);
 document.getElementById("occupiedStat").textContent=`${occupied} occupied`;
 document.getElementById("tenantCount").textContent=state.tenants.length;
 document.getElementById("monthRevenue").textContent=money(total);
 document.getElementById("outstanding").textContent=money(out);
 document.getElementById("defaulterCount").textContent=`${state.tenants.filter(t=>balance(t)>0).length} defaulters`;
 document.getElementById("availableRooms").textContent=available;document.getElementById("occupiedRooms").textContent=occupied;document.getElementById("reservedRooms").textContent=reserved;
 const pct=Math.round((occupied/65)*100);document.getElementById("occupancyPct").textContent=pct+"%";document.getElementById("occupancyRing").style.background=`conic-gradient(#2563eb ${pct*3.6}deg,#edf1f7 0deg)`;
 document.getElementById("heroMode").textContent=state.holiday.enabled?"LONG HOLIDAY":"NORMAL OPERATIONS";document.getElementById("sideMode").textContent=state.holiday.enabled?"Long Holiday":"Normal Operations";
 const recent=state.payments.slice().sort((a,b)=>b.createdAt-a.createdAt).slice(0,5);
 document.getElementById("recentPayments").innerHTML=recent.length?recent.map(p=>{const t=tenantById(p.tenantId);return `<div class="payment-row"><div><strong>${t?.name||"Deleted tenant"}</strong><small>Room ${t?.room||"—"} · ${fmtDate(p.date)}</small></div><b>${money(p.amount)}</b></div>`}).join(""):`<div class="empty">No payments recorded yet.</div>`;
}
function renderRooms(){
 const q=(document.getElementById("roomSearch").value||"").toLowerCase(), f=document.getElementById("roomFilter").value;
 document.getElementById("roomGrid").innerHTML=state.rooms.filter(r=>(f==="all"||r.status===f)&&r.id.includes(q)).map(r=>{
 const t=tenantById(r.tenantId);return `<div class="room"><div class="room-top"><span class="room-num">Room ${r.id}</span><span class="badge ${r.status}">${r.status}</span></div><div class="room-name">${t?t.name:"Available"}</div><div class="room-rent">${money(rentFor(t||{rent:r.rent}))}/month</div>${t?`<button onclick="openTenant('${t.id}')">View tenant</button>`:`<button onclick="assignRoom('${r.id}')">Assign tenant</button>`}</div>`
 }).join("")||`<div class="card">No rooms found.</div>`;
}
function renderTenants(){
 const q=(document.getElementById("tenantSearch").value||"").toLowerCase();
 document.getElementById("tenantTable").innerHTML=state.tenants.filter(t=>(`${t.name} ${t.phone} ${t.room}`).toLowerCase().includes(q)).map(t=>`<tr><td><strong>${t.name}</strong></td><td>${t.phone}</td><td>Room ${t.room}</td><td>${money(rentFor(t))}</td><td class="${balance(t)>0?"balance":"paid"}">${money(balance(t))}</td><td><span class="badge ${balance(t)>0?"occupied":"available"}">${balance(t)>0?"BALANCE":"PAID"}</span></td><td><button class="ghost" onclick="recordFor('${t.id}')">Pay</button></td></tr>`).join("")||`<tr><td colspan="7">No tenants registered.</td></tr>`;
}
function renderPayments(){
 const total=state.payments.reduce((s,p)=>s+Number(p.amount),0);
 document.getElementById("paymentTotal").textContent=money(total);document.getElementById("paymentCount").textContent=state.payments.length;document.getElementById("paymentAvg").textContent=money(state.payments.length?total/state.payments.length:0);
 document.getElementById("paymentTable").innerHTML=state.payments.slice().sort((a,b)=>b.createdAt-a.createdAt).map(p=>{const t=tenantById(p.tenantId);return `<tr><td><strong>${p.receipt}</strong></td><td>${t?.name||"—"}</td><td>${t?`Room ${t.room}`:"—"}</td><td class="paid">${money(p.amount)}</td><td>${p.method}</td><td>${fmtDate(p.date)}</td><td><button class="ghost" onclick="printReceipt('${p.id}')">Print</button></td></tr>`}).join("")||`<tr><td colspan="7">No payments recorded.</td></tr>`;
}
function renderReceipts(){
 document.getElementById("receiptList").innerHTML=state.payments.slice().sort((a,b)=>b.createdAt-a.createdAt).map(p=>{const t=tenantById(p.tenantId);return `<div class="receipt"><div class="receipt-head"><div><div class="receipt-id">${p.receipt}</div><small>M&M HOSTEL</small></div><span class="badge paid">PAID</span></div><div class="receipt-details"><div><span>Student</span><b>${t?.name||"—"}</b></div><div><span>Room</span><b>${t?.room||"—"}</b></div><div><span>Amount</span><b>${money(p.amount)}</b></div><div><span>Method</span><b>${p.method}</b></div><div><span>Date</span><b>${fmtDate(p.date)}</b></div></div><div class="receipt-actions"><button onclick="printReceipt('${p.id}')">Print Receipt</button></div></div>`}).join("")||`<div class="card">No receipts yet.</div>`;
}
function renderDefaulters(){
 const arr=state.tenants.filter(t=>balance(t)>0);
 document.getElementById("defaulterTable").innerHTML=arr.map(t=>{const lp=lastPayment(t);return `<tr><td><strong>${t.name}</strong></td><td>Room ${t.room}</td><td>${money(rentFor(t))}</td><td class="balance">${money(balance(t))}</td><td>${lp?fmtDate(lp.date):"Never"}</td><td><button class="primary" onclick="recordFor('${t.id}')">Collect</button></td></tr>`}).join("")||`<tr><td colspan="6">🎉 No outstanding balances.</td></tr>`;
}
function renderShops(){document.getElementById("shopGrid").innerHTML=state.shops.map(s=>`<div class="shop"><h3>${s.name}</h3><span class="shop-status">${s.tenant}</span><div class="report-line"><span>Monthly rent</span><b>${money(s.rent)}</b></div><button class="ghost">Manage shop</button></div>`).join("")}
function renderReports(){
 const total=state.payments.reduce((s,p)=>s+Number(p.amount),0), occupied=state.rooms.filter(r=>r.status==="occupied").length;
 document.getElementById("financialReport").innerHTML=`<div class="report-line"><span>Total collected</span><b>${money(total)}</b></div><div class="report-line"><span>Outstanding</span><b>${money(state.tenants.reduce((s,t)=>s+balance(t),0))}</b></div><div class="report-line"><span>Transactions</span><b>${state.payments.length}</b></div>`;
 document.getElementById("occupancyReport").innerHTML=`<div class="report-line"><span>Total rooms</span><b>65</b></div><div class="report-line"><span>Occupied</span><b>${occupied}</b></div><div class="report-line"><span>Available</span><b>${65-occupied}</b></div>`;
 document.getElementById("holidayReport").innerHTML=`<div class="report-line"><span>Mode</span><b>${state.holiday.enabled?"LONG HOLIDAY":"NORMAL"}</b></div><div class="report-line"><span>Holiday rent</span><b>${money(state.holiday.rent)}</b></div><div class="report-line"><span>General reporting</span><b>${fmtDate(state.holiday.generalReport)}</b></div>`;
}
function renderHoliday(){
 document.getElementById("holidaySwitch").checked=state.holiday.enabled;document.getElementById("holidayStart").value=state.holiday.start;document.getElementById("generalReport").value=state.holiday.generalReport;document.getElementById("holidayRent").value=state.holiday.rent;document.getElementById("holidayNotes").value=state.holiday.notes;
 document.getElementById("reportingList").innerHTML=state.tenants.map(t=>{const individual=t.reportingDate||"";return `<div class="report-row"><div><strong>${t.name}</strong><div>Room ${t.room}</div></div><div>Default: ${fmtDate(state.holiday.generalReport)}</div><input type="date" value="${individual}" onchange="setReportDate('${t.id}',this.value)"><button onclick="markReported('${t.id}')">${t.reported?"Reported ✓":"Mark Reported"}</button></div>`}).join("")||`<div class="empty">No tenants to report.</div>`;
}
function renderSettings(){document.getElementById("hostelName").value=state.settings.hostelName;document.getElementById("managerName").value=state.settings.managerName;document.getElementById("defaultRent").value=state.settings.defaultRent}
function renderAll(){renderDashboard();renderRooms();renderTenants();renderPayments();renderReceipts();renderDefaulters();renderShops();renderReports();renderHoliday();renderSettings();populateRoomSelect();populateTenantSelect()}
function populateRoomSelect(){const sel=document.getElementById("tenantRoom");if(!sel)return;sel.innerHTML=state.rooms.filter(r=>r.status==="available").map(r=>`<option value="${r.id}">Room ${r.id}</option>`).join("")||`<option value="">No rooms available</option>`}
function populateTenantSelect(){const sel=document.getElementById("paymentTenant");if(!sel)return;sel.innerHTML=state.tenants.map(t=>`<option value="${t.id}">${t.name} — Room ${t.room}</option>`).join("")||`<option value="">No tenants</option>`}
function openModal(id){document.getElementById(id).classList.add("open");populateRoomSelect();populateTenantSelect()}
function closeModal(id){document.getElementById(id).classList.remove("open")}
function openTenant(id){go("tenants");document.getElementById("tenantSearch").value=tenantById(id)?.name||"";renderTenants()}
function assignRoom(room){openModal("tenantModal");setTimeout(()=>{document.getElementById("tenantRoom").value=room},0)}
function recordFor(id){openModal("paymentModal");setTimeout(()=>document.getElementById("paymentTenant").value=id,0)}
document.getElementById("tenantForm").onsubmit=e=>{e.preventDefault();const f=new FormData(e.target),room=roomById(f.get("room"));if(!room){toast("No room selected");return}const id="T"+Date.now();const t={id,name:f.get("name").trim(),phone:f.get("phone").trim(),room:room.id,rent:Number(f.get("rent")||5000),balance:Number(f.get("rent")||5000),reported:false,reportingDate:""};state.tenants.push(t);room.status="occupied";room.tenantId=id;room.rent=t.rent;save();e.target.reset();closeModal("tenantModal");toast("Tenant added successfully")};
document.getElementById("paymentForm").onsubmit=e=>{e.preventDefault();const f=new FormData(e.target),t=tenantById(f.get("tenant"));if(!t)return;const amount=Number(f.get("amount"));t.balance=Math.max(0,t.balance-amount);const p={id:"P"+Date.now(),receipt:"MM-"+new Date().getFullYear()+"-"+String(state.payments.length+1).padStart(4,"0"),tenantId:t.id,amount,method:f.get("method"),date:f.get("date"),createdAt:Date.now()};state.payments.push(p);save();e.target.reset();document.getElementById("paymentDate").value=todayISO();closeModal("paymentModal");toast(`Payment saved — ${p.receipt}`)};
document.getElementById("paymentDate").value=todayISO();
document.getElementById("holidaySwitch").onchange=e=>{state.holiday.enabled=e.target.checked;save();toast(e.target.checked?"Long Holiday Mode enabled":"Normal Operations restored")};
document.getElementById("saveHoliday").onclick=()=>{state.holiday.start=document.getElementById("holidayStart").value;state.holiday.generalReport=document.getElementById("generalReport").value;state.holiday.rent=Number(document.getElementById("holidayRent").value||2000);state.holiday.notes=document.getElementById("holidayNotes").value;save();toast("Holiday settings saved")};
function setReportDate(id,v){const t=tenantById(id);if(t){t.reportingDate=v;save()}}
function markReported(id){const t=tenantById(id);if(t){t.reported=true;save();toast(`${t.name} marked as reported`)}} 
document.getElementById("reportAll").onclick=()=>{state.tenants.forEach(t=>{t.reported=true;t.reportingDate=t.reportingDate||state.holiday.generalReport});save();toast("All students marked as reported")};
document.getElementById("saveSettings").onclick=()=>{state.settings.hostelName=document.getElementById("hostelName").value;state.settings.managerName=document.getElementById("managerName").value;state.settings.defaultRent=Number(document.getElementById("defaultRent").value||5000);state.rooms.forEach(r=>{if(r.status==="available")r.rent=state.settings.defaultRent});save();toast("Settings saved")};
document.getElementById("clearData").onclick=()=>{if(confirm("Reset all M&M demo data? This cannot be undone.")){state=structuredClone(defaultState);save();toast("Demo data reset")}};
document.getElementById("roomSearch").oninput=renderRooms;document.getElementById("roomFilter").onchange=renderRooms;document.getElementById("tenantSearch").oninput=renderTenants;
function printReceipt(id){const p=state.payments.find(x=>x.id===id);if(!p)return;const t=tenantById(p.tenantId);const w=window.open("","_blank","width=500,height=650");w.document.write(`<html><head><title>${p.receipt}</title><style>body{font-family:Arial;padding:30px;color:#172033}h1{text-align:center}hr{border:0;border-top:1px dashed #aaa;margin:20px 0}.row{display:flex;justify-content:space-between;padding:9px 0}small{color:#667085}</style></head><body><h1>M&M HOSTEL</h1><div style="text-align:center"><small>Official Payment Receipt</small></div><hr><div class="row"><span>Receipt</span><b>${p.receipt}</b></div><div class="row"><span>Student</span><b>${t?.name||"—"}</b></div><div class="row"><span>Room</span><b>${t?.room||"—"}</b></div><div class="row"><span>Amount</span><b>KSh ${Number(p.amount).toLocaleString()}</b></div><div class="row"><span>Method</span><b>${p.method}</b></div><div class="row"><span>Date</span><b>${fmtDate(p.date)}</b></div><hr><p style="text-align:center">Thank you.</p><script>window.print();<\/script></body></html>`);w.document.close()}
renderAll();
